package modele;

import java.sql.*;
import bdd.ConnexionBDD;

public class DashboardModele {

    /* ================= CHARGER LES DONNEES ================= */

    public static ResultSet getComptes(int idUser) throws SQLException {
        Connection c = ConnexionBDD.getConnexion();
        PreparedStatement ps = c.prepareStatement(
                "SELECT * FROM compte_bancaire WHERE id_user=?");
        ps.setInt(1, idUser);
        return ps.executeQuery();
    }

    public static ResultSet getCompteById(int idCompte) throws SQLException {
        Connection c = ConnexionBDD.getConnexion();
        PreparedStatement ps = c.prepareStatement(
                "SELECT * FROM compte_bancaire WHERE id_compte=?");
        ps.setInt(1, idCompte);
        return ps.executeQuery();
    }

    public static ResultSet getOperations(int idUser) throws SQLException {
        Connection c = ConnexionBDD.getConnexion();
        PreparedStatement ps = c.prepareStatement(
                "SELECT o.id_operations, o.libelle, o.montant, o.date_depense, o.description, c.nom_compte " +
                        "FROM operations o JOIN compte_bancaire c ON o.id_compte=c.id_compte " +
                        "WHERE c.id_user=?");
        ps.setInt(1, idUser);
        return ps.executeQuery();
    }

    public static ResultSet getOperationById(int idOperation) throws SQLException {
        Connection c = ConnexionBDD.getConnexion();
        PreparedStatement ps = c.prepareStatement(
                "SELECT * FROM operations WHERE id_operations=?");
        ps.setInt(1, idOperation);
        return ps.executeQuery();
    }

    public static ResultSet getCategories() throws SQLException {
        Connection c = ConnexionBDD.getConnexion();

        String sql =
                "SELECT cat.id_categorie, cat.libelle, cat.description, t.libelle AS type " +
                "FROM categorie cat " +
                "JOIN type_operation t ON cat.id_type = t.id_type";

        return c.createStatement().executeQuery(sql);
    }

    public static ResultSet getCategorieById(int idCategorie) throws SQLException {
        Connection c = ConnexionBDD.getConnexion();

        PreparedStatement ps = c.prepareStatement(
                "SELECT * FROM categorie WHERE id_categorie=?");

        ps.setInt(1, idCategorie);
        return ps.executeQuery();
    }

    /* ================= USERS ================= */

    public static ResultSet getUsers() throws SQLException {
        Connection c = ConnexionBDD.getConnexion();
        return c.createStatement().executeQuery("SELECT * FROM utilisateur");
    }

    public static ResultSet getUtilisateurById(int idUser) throws SQLException {
        Connection c = ConnexionBDD.getConnexion();
        PreparedStatement ps = c.prepareStatement(
                "SELECT * FROM utilisateur WHERE id_user=?");
        ps.setInt(1, idUser);
        return ps.executeQuery();
    }

    /* ================= AJOUTER ================= */

    public static void ajouterCompte(String nom, double solde, String type, int idUser) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "INSERT INTO compte_bancaire(nom_compte, solde, type, id_user) VALUES (?, ?, ?, ?)");

        ps.setString(1, nom);
        ps.setDouble(2, solde);
        ps.setString(3, type);
        ps.setInt(4, idUser);

        ps.executeUpdate();
    }

public static void ajouterOperation(String libelle, double montant, String date, String desc, int idCompte, int idCategorie) throws SQLException {

    Connection c = ConnexionBDD.getConnexion();

    PreparedStatement psSolde = c.prepareStatement(
        "SELECT solde FROM compte_bancaire WHERE id_compte=?");
    psSolde.setInt(1, idCompte);
    ResultSet rs = psSolde.executeQuery();

    double ancienSolde = 0;
    if (rs.next()) {
        ancienSolde = rs.getDouble("solde");
    }

    double nouveauSolde = ancienSolde + montant;

    PreparedStatement ps = c.prepareStatement(
        "INSERT INTO operations(libelle, montant, date_depense, description, id_compte, id_categorie) VALUES (?, ?, ?, ?, ?, ?)");

    ps.setString(1, libelle);
    ps.setDouble(2, montant);
    ps.setString(3, date);
    ps.setString(4, desc);
    ps.setInt(5, idCompte);
    ps.setInt(6, idCategorie);
    ps.executeUpdate();

    PreparedStatement psUpdate = c.prepareStatement(
        "UPDATE compte_bancaire SET solde=? WHERE id_compte=?");

    psUpdate.setDouble(1, nouveauSolde);
    psUpdate.setInt(2, idCompte);
    psUpdate.executeUpdate();

}

    public static void ajouterCategorie(String libelle, String desc, int idType) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "INSERT INTO categorie(libelle, description, id_type) VALUES (?, ?, ?)");

        ps.setString(1, libelle);
        ps.setString(2, desc);
        ps.setInt(3, idType);

        ps.executeUpdate();
    }

public static void ajouterUtilisateur(String user, String mdp,
                                      String nom, String prenom,
                                      boolean isAdmin) throws SQLException {

    PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
        "INSERT INTO utilisateur(user, mdp, nom, prenom, role) VALUES (?, ?, ?, ?, ?)");

    ps.setString(1, user);
    ps.setString(2, mdp);
    ps.setString(3, nom);
    ps.setString(4, prenom);
    ps.setString(5, isAdmin ? "admin" : "user");

    ps.executeUpdate();
}


    /* ================= MODIFIER ================= */

    public static void modifierCompte(int idCompte, String nom, double solde, String type) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "UPDATE compte_bancaire SET nom_compte=?, solde=?, type=? WHERE id_compte=?");

        ps.setString(1, nom);
        ps.setDouble(2, solde);
        ps.setString(3, type);
        ps.setInt(4, idCompte);

        ps.executeUpdate();
    }

    public static void modifierOperation(int idOperation, String libelle, double montant, String date, String desc, int idCompte, int idCategorie) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "UPDATE operations SET libelle=?, montant=?, date_depense=?, description=?, id_compte=?, id_categorie=? WHERE id_operations=?");

        ps.setString(1, libelle);
        ps.setDouble(2, montant);
        ps.setString(3, date);
        ps.setString(4, desc);
        ps.setInt(5, idCompte);
        ps.setInt(6, idCategorie);
        ps.setInt(7, idOperation);

        ps.executeUpdate();
    }

    public static void modifierCategorie(int idCategorie, String libelle, String desc, int idType) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "UPDATE categorie SET libelle=?, description=?, id_type=? WHERE id_categorie=?");

        ps.setString(1, libelle);
        ps.setString(2, desc);
        ps.setInt(3, idType);
        ps.setInt(4, idCategorie);

        ps.executeUpdate();
    }

    public static void modifierUtilisateur(int idUser, String login, String mdp, boolean isAdmin) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "UPDATE utilisateur SET user=?, mdp=?, role=? WHERE id_user=?");

        ps.setString(1, login);
        ps.setString(2, mdp);
        ps.setString(3, isAdmin ? "ADMIN" : "USER");
        ps.setInt(4, idUser);

        ps.executeUpdate();
    }

    /* ================= SUPPRIMER ================= */

    public static void supprimerCompte(int idCompte) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "DELETE FROM compte_bancaire WHERE id_compte=?");

        ps.setInt(1, idCompte);
        ps.executeUpdate();
    }

    public static void supprimerOperation(int idOperation) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "DELETE FROM operations WHERE id_operations=?");

        ps.setInt(1, idOperation);
        ps.executeUpdate();
    }

    public static void supprimerCategorie(int idCategorie) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "DELETE FROM categorie WHERE id_categorie=?");

        ps.setInt(1, idCategorie);
        ps.executeUpdate();
    }

    public static void supprimerUtilisateur(int idUser) throws SQLException {
        PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                "DELETE FROM utilisateur WHERE id_user=?");

        ps.setInt(1, idUser);
        ps.executeUpdate();
    }
}