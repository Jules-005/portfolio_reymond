package modele;

import java.sql.*;

import bdd.ConnexionBDD;

public class UtilisateurModele {

    public static ResultSet connexion(String user, String mdp) throws SQLException {
        Connection c = ConnexionBDD.getConnexion();
        String sql = "SELECT id_user, role FROM utilisateur WHERE user=? AND mdp=?";
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setString(1, user);
        ps.setString(2, mdp);
        return ps.executeQuery();
    }

    public static void inscription(String user, String mdp, String nom, String prenom) throws SQLException {
        Connection c = ConnexionBDD.getConnexion();
        String sql = "INSERT INTO utilisateur(user, mdp, nom, prenom, role) VALUES (?,?,?,?,?)";
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setString(1, user);
        ps.setString(2, mdp);
        ps.setString(3, nom);
        ps.setString(4, prenom);
        ps.setString(5, "user"); // rôle par défaut
        ps.executeUpdate();
    }
}
