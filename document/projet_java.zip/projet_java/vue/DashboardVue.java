package vue;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

import controleur.DashboardControleur;

public class DashboardVue extends JFrame {

    // Tables et modèles
    public JTable tableComptes, tableOperations, tableCategories, tableUsers;
    public DefaultTableModel modelComptes, modelOperations, modelCategories, modelUsers;

    // Boutons
    public JButton btnAddCompte, btnAddOp, btnAddCat, btnAddUser;
    public JButton btnDeconnexion;

    private DashboardControleur controleur;

    public DashboardVue(boolean isAdmin) {

        setTitle("Dashboard Banque");
        setSize(1100, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Comptes", panelComptes());
        tabs.addTab("Opérations", panelOperations());
        tabs.addTab("Catégories", panelCategories());

        // 👉 Onglet ADMIN uniquement
        if (isAdmin) {
            tabs.addTab("Utilisateurs", panelUsers());
        }

        add(tabs, BorderLayout.CENTER);
        add(panelBas(), BorderLayout.SOUTH);

        setVisible(true);
    }

    /* ================= CONTROLEUR ================= */
    public void setControleur(DashboardControleur controleur) {
        this.controleur = controleur;
    }

    public DashboardControleur getControleur() {
        return this.controleur;
    }

    /* ================= UTILS ================= */
    private void cacherColonneId(JTable table) {
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);
    }

    /* ================= BAS ================= */
    private JPanel panelBas() {
        JPanel panel = new JPanel();
        btnDeconnexion = new JButton("Se déconnecter");
        panel.add(btnDeconnexion);
        return panel;
    }

    /* ================= COMPTES ================= */
    private JPanel panelComptes() {

        modelComptes = new DefaultTableModel(
                new Object[]{"ID", "Nom", "Solde", "Type", "Modifier", "Supprimer"}, 0
        );

        tableComptes = new JTable(modelComptes);
        cacherColonneId(tableComptes);

        btnAddCompte = new JButton("Ajouter");

        JPanel btns = new JPanel();
        btns.add(btnAddCompte);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tableComptes), BorderLayout.CENTER);
        panel.add(btns, BorderLayout.SOUTH);

        return panel;
    }

    /* ================= OPERATIONS ================= */
    private JPanel panelOperations() {

        modelOperations = new DefaultTableModel(
                new Object[]{"ID", "Libellé", "Montant", "Date", "Description", "Compte", "Modifier", "Supprimer"}, 0
        );

        tableOperations = new JTable(modelOperations);
        cacherColonneId(tableOperations);

        btnAddOp = new JButton("Ajouter");

        JPanel btns = new JPanel();
        btns.add(btnAddOp);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tableOperations), BorderLayout.CENTER);
        panel.add(btns, BorderLayout.SOUTH);

        return panel;
    }

    /* ================= CATEGORIES ================= */
    private JPanel panelCategories() {

        modelCategories = new DefaultTableModel(
                new Object[]{"ID", "Libellé", "Description", "Type", "Modifier", "Supprimer"}, 0
        );

        tableCategories = new JTable(modelCategories);
        cacherColonneId(tableCategories);

        btnAddCat = new JButton("Ajouter");

        JPanel btns = new JPanel();
        btns.add(btnAddCat);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tableCategories), BorderLayout.CENTER);
        panel.add(btns, BorderLayout.SOUTH);

        return panel;
    }

    /* ================= UTILISATEURS (ADMIN) ================= */
    private JPanel panelUsers() {

        modelUsers = new DefaultTableModel(
                new Object[]{"ID", "Login", "Rôle", "Modifier", "Supprimer"}, 0
        );

        tableUsers = new JTable(modelUsers);
        cacherColonneId(tableUsers);

        btnAddUser = new JButton("Ajouter");

        JPanel btns = new JPanel();
        btns.add(btnAddUser);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tableUsers), BorderLayout.CENTER);
        panel.add(btns, BorderLayout.SOUTH);

        return panel;
    }

    
}
