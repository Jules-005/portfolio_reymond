package vue;

import javax.swing.*;
import java.awt.*;

public class InscriptionVue extends JFrame {

    public JTextField txtUser, txtNom, txtPrenom;
    public JPasswordField txtMdp;
    public JButton btnInscrire, btnRetour;

    public InscriptionVue() {
        setTitle("Inscription");
        setSize(420, 330);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8,8,8,8);

        // Nom utilisateur
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        add(new JLabel("Nom d'utilisateur :"), gbc);

        txtUser = new JTextField(18);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        add(txtUser, gbc);

        // Mot de passe
        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
        add(new JLabel("Mot de passe :"), gbc);

        txtMdp = new JPasswordField(18);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        add(txtMdp, gbc);

        // Nom
        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST;
        add(new JLabel("Nom :"), gbc);

        txtNom = new JTextField(18);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        add(txtNom, gbc);

        // Prénom
        gbc.gridx = 0; gbc.gridy = 3; gbc.anchor = GridBagConstraints.EAST;
        add(new JLabel("Prénom :"), gbc);

        txtPrenom = new JTextField(18);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        add(txtPrenom, gbc);

        // Bouton s'inscrire
        btnInscrire = new JButton("S'inscrire");
        btnInscrire.setPreferredSize(new Dimension(200, 30));
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(btnInscrire, gbc);

        // Bouton retour
        btnRetour = new JButton("Retour à la connexion");
        btnRetour.setPreferredSize(new Dimension(200, 30));
        gbc.gridy = 5;
        add(btnRetour, gbc);

        setVisible(true);
    }
}
