package vue;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class FormulaireVue extends JDialog {

    // -------- Champs Utilisateur --------
    public JTextField tfUserLogin, tfUserNom, tfUserPrenom, tfUserMdp;
    public JCheckBox cbAdmin;

    // -------- Champs pour Compte --------
    public JTextField tfNom, tfSolde, tfType;

    // -------- Champs pour Opération --------
    public JTextField tfLibelle, tfMontant, tfDate, tfDesc;
    public JComboBox<String> cbCompte;
    public JComboBox<String> cbCategorie;
    public ArrayList<Integer> comptesIds;
    public ArrayList<Integer> categoriesIds;

    // -------- Champs pour Catégorie --------
    public JTextField tfCatLibelle, tfCatDesc;
    public JComboBox<String> cbTypeOp;

    // -------- Boutons --------
    public JButton btnAjouter, btnAnnuler;

    public FormulaireVue(JFrame parent, String type) {

        super(parent, "Ajouter " + type, true);

        setSize(420, 320);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(0, 2, 10, 10));

        switch (type.toLowerCase()) {

            case "compte":
                buildCompteForm();
                break;

            case "operation":
                buildOperationForm();
                break;

            case "categorie":
                buildCategorieForm();
                break;
            case "utilisateur":
            buildUtilisateurForm();
        break;

        }

        // -------- Boutons --------
        btnAjouter = new JButton("Ajouter");
        btnAnnuler = new JButton("Annuler");

        add(btnAjouter);
        add(btnAnnuler);
    }

    // ===============================
    // FORMULAIRE COMPTE
    // ===============================
    private void buildCompteForm() {

        add(new JLabel("Nom du compte :"));
        tfNom = new JTextField();
        add(tfNom);

        add(new JLabel("Solde :"));
        tfSolde = new JTextField("0");
        add(tfSolde);

        add(new JLabel("Type :"));
        tfType = new JTextField();
        add(tfType);
    }

    // ===============================
    // FORMULAIRE OPERATION
    // ===============================
    private void buildOperationForm() {

        add(new JLabel("Libellé :"));
        tfLibelle = new JTextField();
        add(tfLibelle);

        add(new JLabel("Montant :"));
        tfMontant = new JTextField();
        add(tfMontant);

        add(new JLabel("Date (YYYY-MM-DD) :"));
        tfDate = new JTextField();
        add(tfDate);

        add(new JLabel("Description :"));
        tfDesc = new JTextField();
        add(tfDesc);

        // ---------- Compte ----------
        add(new JLabel("Compte :"));
        cbCompte = new JComboBox<>();
        comptesIds = new ArrayList<>();
        add(cbCompte);

        // ---------- Catégorie ----------
        add(new JLabel("Catégorie :"));
        cbCategorie = new JComboBox<>();
        categoriesIds = new ArrayList<>();
        add(cbCategorie);
    }

    // ===============================
    // FORMULAIRE CATEGORIE
    // ===============================
    private void buildCategorieForm() {

        add(new JLabel("Libellé :"));
        tfCatLibelle = new JTextField();
        add(tfCatLibelle);

        add(new JLabel("Description :"));
        tfCatDesc = new JTextField();
        add(tfCatDesc);

        add(new JLabel("Type d'opération :"));
        cbTypeOp = new JComboBox<>(new String[]{"Débit", "Crédit"});
        add(cbTypeOp);
    }
        // ===============================
    // FORMULAIRE Utilisateur
    // ===============================
private void buildUtilisateurForm() {

    add(new JLabel("Login :"));
    tfUserLogin = new JTextField();
    add(tfUserLogin);

    add(new JLabel("Nom :"));
    tfUserNom = new JTextField();
    add(tfUserNom);

    add(new JLabel("Prénom :"));
    tfUserPrenom = new JTextField();
    add(tfUserPrenom);

    add(new JLabel("Mot de passe :"));
    tfUserMdp = new JTextField();
    add(tfUserMdp);

    add(new JLabel("Admin :"));
    cbAdmin = new JCheckBox();
    add(cbAdmin);
}


}
