package vue;

import javax.swing.*;
import java.awt.*;

public class LoginVue extends JFrame {

    public JTextField txtUser;
    public JPasswordField txtMdp;
    public JButton btnConnexion, btnInscription;

    public LoginVue() {
        setTitle("Connexion Banque");
        setSize(400, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1; 

        // Identifiant
        JLabel lblUser = new JLabel("Identifiant :");
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        add(lblUser, gbc);

        txtUser = new JTextField(20);   // largeur
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1;
        add(txtUser, gbc);

        // Mot de passe
        JLabel lblMdp = new JLabel("Mot de passe :");
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        add(lblMdp, gbc);

        txtMdp = new JPasswordField(20);
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1;
        add(txtMdp, gbc);

        // Bouton connexion
        btnConnexion = new JButton("Se connecter");
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(btnConnexion, gbc);

        // Bouton inscription
        btnInscription = new JButton("S'inscrire");
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(btnInscription, gbc);

        setVisible(true);
    }
}
