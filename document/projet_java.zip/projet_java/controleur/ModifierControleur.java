package controleur;

import vue.DashboardVue;
import vue.FormulaireVue;
import modele.DashboardModele;

import javax.swing.*;

import bdd.ConnexionBDD;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ModifierControleur {

    private int idUser;
    private DashboardVue vue;

    public ModifierControleur(String type, int idElement, DashboardVue vue, int idUser) {
        this.idUser = idUser;
        this.vue = vue;

        // Masquer le dashboard pendant la modification
        vue.setVisible(false);

        // Crée le formulaire
        FormulaireVue form = new FormulaireVue(vue, type);

        // Réafficher le dashboard quand le formulaire se ferme
        form.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                vue.setVisible(true);
            }
        });

        // Charger les comptes et catégories si type operation
        if (type.equals("operation")) {
            form.comptesIds = new ArrayList<>();
            form.categoriesIds = new ArrayList<>();
            try {
                // Comptes
                ResultSet rsComptes = DashboardModele.getComptes(idUser);
                while (rsComptes.next()) {
                    form.cbCompte.addItem(rsComptes.getString("nom_compte"));
                    form.comptesIds.add(rsComptes.getInt("id_compte"));
                }
                // Catégories
                ResultSet rsCats = DashboardModele.getCategories();
                while (rsCats.next()) {
                    form.cbCategorie.addItem(rsCats.getString("libelle"));
                    form.categoriesIds.add(rsCats.getInt("id_categorie"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        remplirChampsExistants(type, idElement, form);

        // Modifier le bouton Ajouter pour qu’il serve à modifier
        form.btnAjouter.setText("Modifier");
        form.btnAjouter.addActionListener(e -> modifier(type, idElement, form));

        // Annuler = fermer formulaire et réafficher dashboard
        form.btnAnnuler.addActionListener(e -> form.dispose());

        form.setVisible(true);
    }

    // -------- Remplir les champs --------
    private void remplirChampsExistants(String type, int idElement, FormulaireVue form) {
        try {
            switch (type) {
                case "compte":
                    ResultSet rsCompte = DashboardModele.getCompteById(idElement);
                    if (rsCompte.next()) {
                        form.tfNom.setText(rsCompte.getString("nom_compte"));
                        form.tfSolde.setText(String.valueOf(rsCompte.getDouble("solde")));
                        form.tfType.setText(rsCompte.getString("type"));
                    }
                    break;

                case "operation":
                    ResultSet rsOp = DashboardModele.getOperationById(idElement);
                    if (rsOp.next()) {
                        form.tfLibelle.setText(rsOp.getString("libelle"));
                        form.tfMontant.setText(String.valueOf(rsOp.getDouble("montant")));
                        form.tfDate.setText(rsOp.getString("date_depense"));
                        form.tfDesc.setText(rsOp.getString("description"));

                        // Compte sélectionné
                        int idCompte = rsOp.getInt("id_compte");
                        int indexCompte = form.comptesIds.indexOf(idCompte);
                        if (indexCompte >= 0) form.cbCompte.setSelectedIndex(indexCompte);

                        // Catégorie sélectionnée
                        int idCategorie = rsOp.getInt("id_categorie");
                        int indexCat = form.categoriesIds.indexOf(idCategorie);
                        if (indexCat >= 0) form.cbCategorie.setSelectedIndex(indexCat);
                    }
                    break;

                case "categorie":
                    ResultSet rsCat = DashboardModele.getCategorieById(idElement);
                    if (rsCat.next()) {
                        form.tfCatLibelle.setText(rsCat.getString("libelle"));
                        form.tfCatDesc.setText(rsCat.getString("description"));
                        form.cbTypeOp.setSelectedIndex(rsCat.getInt("id_type") - 1);
                    }
                    break;
                case "utilisateur":
                    ResultSet rsUser = DashboardModele.getUtilisateurById(idElement);
                    if (rsUser.next()) {
                        form.tfUserLogin.setText(rsUser.getString("user"));
                        form.tfUserNom.setText(rsUser.getString("nom"));
                        form.tfUserPrenom.setText(rsUser.getString("prenom"));
                        form.tfUserMdp.setText(rsUser.getString("mdp"));
                        form.cbAdmin.setSelected(rsUser.getString("role").equals("admin"));
                    }
                    break;

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // -------- Modifier --------
    private void modifier(String type, int idElement, FormulaireVue form) {
        try {
            switch (type) {
                case "compte":
                    DashboardModele.modifierCompte(
                            idElement,
                            form.tfNom.getText().trim(),
                            Double.parseDouble(form.tfSolde.getText().trim()),
                            form.tfType.getText().trim()
                    );
                    break;

                case "utilisateur":

                    String login = form.tfUserLogin.getText().trim();
                    String nom = form.tfUserNom.getText().trim();
                    String prenom = form.tfUserPrenom.getText().trim();
                    String mdp = form.tfUserMdp.getText().trim();
                    boolean admin = form.cbAdmin.isSelected();

                    if(login.isEmpty() || nom.isEmpty() || prenom.isEmpty() || mdp.isEmpty()){
                        JOptionPane.showMessageDialog(form,"Tous les champs obligatoires");
                        return;
                    }

                    PreparedStatement ps = ConnexionBDD.getConnexion().prepareStatement(
                        "UPDATE utilisateur SET user=?, mdp=?, nom=?, prenom=?, role=? WHERE id_user=?");

                    ps.setString(1, login);
                    ps.setString(2, mdp);
                    ps.setString(3, nom);
                    ps.setString(4, prenom);
                    ps.setString(5, admin ? "admin" : "user");
                    ps.setInt(6, idElement);

                    ps.executeUpdate();
                    break;



                case "operation":
                    int indexCompte = form.cbCompte.getSelectedIndex();
                    if (indexCompte < 0) {
                        JOptionPane.showMessageDialog(form, "Sélectionnez un compte !");
                        return;
                    }
                    int idCompte = form.comptesIds.get(indexCompte);

                    int indexCat = form.cbCategorie.getSelectedIndex();
                    if (indexCat < 0) {
                        JOptionPane.showMessageDialog(form, "Sélectionnez une catégorie !");
                        return;
                    }
                    int idCategorie = form.categoriesIds.get(indexCat);

                    DashboardModele.modifierOperation(
                            idElement,
                            form.tfLibelle.getText().trim(),
                            Double.parseDouble(form.tfMontant.getText().trim()),
                            form.tfDate.getText().trim(),
                            form.tfDesc.getText().trim(),
                            idCompte,
                            idCategorie
                    );
                    break;

                case "categorie":
                    DashboardModele.modifierCategorie(
                            idElement,
                            form.tfCatLibelle.getText().trim(),
                            form.tfCatDesc.getText().trim(),
                            form.cbTypeOp.getSelectedIndex() + 1
                    );
                    break;
            }

            // Rafraîchir les tableaux existants
            vue.modelComptes.setRowCount(0);
            vue.modelOperations.setRowCount(0);
            vue.modelCategories.setRowCount(0);

            try {
                // Comptes
                ResultSet rsC = DashboardModele.getComptes(idUser);
                while (rsC.next()) {
                    vue.modelComptes.addRow(new Object[]{
                            rsC.getInt("id_compte"),
                            rsC.getString("nom_compte"),
                            rsC.getDouble("solde"),
                            rsC.getString("type"),
                            "Modifier",
                            "Supprimer"
                    });
                }

                // Opérations
                ResultSet rsO = DashboardModele.getOperations(idUser);
                while (rsO.next()) {
                    vue.modelOperations.addRow(new Object[]{
                            rsO.getInt("id_operations"),
                            rsO.getString("libelle"),
                            rsO.getDouble("montant"),
                            rsO.getDate("date_depense"),
                            rsO.getString("description"),
                            rsO.getString("nom_compte"),
                            "Modifier",
                            "Supprimer"
                    });
                }

                // Catégories
                ResultSet rsCat = DashboardModele.getCategories();
                while (rsCat.next()) {
                    vue.modelCategories.addRow(new Object[]{
                            rsCat.getInt("id_categorie"),
                            rsCat.getString("libelle"),
                            rsCat.getString("description"),
                            rsCat.getString("type"),
                            "Modifier",
                            "Supprimer"
                    });
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }

            form.dispose();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(form, "Erreur : " + ex.getMessage());
        }
    }
}
