package controleur;

import vue.DashboardVue;
import modele.DashboardModele;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class DashboardControleur {

    private DashboardVue vue;
    private int idUser;
    private boolean isAdmin;

    public DashboardControleur(int idUser, boolean isAdmin) {

        this.idUser = idUser;
        this.isAdmin = isAdmin;

        vue = new DashboardVue(isAdmin);

        vue.addWindowListener(new WindowAdapter() {
            @Override
            public void windowActivated(WindowEvent e) {
                rafraichirTout();
            }
        });

        rafraichirTout();

        /* ================= BOUTONS AJOUTER ================= */

        vue.btnAddCompte.addActionListener(e -> {
            vue.setVisible(false);
            new AjouterControleur("compte", vue, idUser);
        });

        vue.btnAddOp.addActionListener(e -> {
            vue.setVisible(false);
            new AjouterControleur("operation", vue, idUser);
        });

        vue.btnAddCat.addActionListener(e -> {
            vue.setVisible(false);
            new AjouterControleur("categorie", vue, idUser);
        });

        if (isAdmin && vue.btnAddUser != null) {
            vue.btnAddUser.addActionListener(e -> {
                vue.setVisible(false);
                new AjouterControleur("utilisateur", vue, idUser);
            });
        }

        vue.btnDeconnexion.addActionListener(e -> deconnexion());

        gererActionsLignes();
    }

    private void deconnexion() {
        vue.dispose();
        new LoginControleur();
    }

    /* ================= GESTION DES CLICS ================= */
    private void gererActionsLignes() {

        SupprimerControleur supCtrl = new SupprimerControleur(vue);

        /* ===== COMPTES ===== */
        vue.tableComptes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {

                int row = vue.tableComptes.rowAtPoint(e.getPoint());
                int col = vue.tableComptes.columnAtPoint(e.getPoint());
                if (row < 0 || col < 0) return;

                int id = (int) vue.modelComptes.getValueAt(row, 0);
                int colModifier = vue.modelComptes.getColumnCount() - 2;
                int colSupprimer = vue.modelComptes.getColumnCount() - 1;

                if (col == colModifier) {
                    vue.setVisible(false);
                    new ModifierControleur("compte", id, vue, idUser);
                }

                if (col == colSupprimer) {
                    supCtrl.supprimer("compte", id);
                    chargerComptes();
                }
            }
        });

        /* ===== OPERATIONS ===== */
        vue.tableOperations.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {

                int row = vue.tableOperations.rowAtPoint(e.getPoint());
                int col = vue.tableOperations.columnAtPoint(e.getPoint());
                if (row < 0 || col < 0) return;

                int id = (int) vue.modelOperations.getValueAt(row, 0);
                int colModifier = vue.modelOperations.getColumnCount() - 2;
                int colSupprimer = vue.modelOperations.getColumnCount() - 1;

                if (col == colModifier) {
                    vue.setVisible(false);
                    new ModifierControleur("operation", id, vue, idUser);
                }

                if (col == colSupprimer) {
                    supCtrl.supprimer("operation", id);
                    chargerOperations();
                }
            }
        });

        /* ===== CATEGORIES ===== */
        vue.tableCategories.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {

                int row = vue.tableCategories.rowAtPoint(e.getPoint());
                int col = vue.tableCategories.columnAtPoint(e.getPoint());
                if (row < 0 || col < 0) return;

                int id = (int) vue.modelCategories.getValueAt(row, 0);
                int colModifier = vue.modelCategories.getColumnCount() - 2;
                int colSupprimer = vue.modelCategories.getColumnCount() - 1;

                if (col == colModifier) {
                    vue.setVisible(false);
                    new ModifierControleur("categorie", id, vue, idUser);
                }

                if (col == colSupprimer) {
                    supCtrl.supprimer("categorie", id);
                    chargerCategories();
                }
            }
        });



        /* ===== USERS ADMIN ===== */
        if (isAdmin && vue.tableUsers != null) {

            vue.tableUsers.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent e) {

                    int row = vue.tableUsers.rowAtPoint(e.getPoint());
                    int col = vue.tableUsers.columnAtPoint(e.getPoint());
                    if (row < 0 || col < 0) return;

                    int id = (int) vue.modelUsers.getValueAt(row, 0);
                    int colModifier = vue.modelUsers.getColumnCount() - 2;
                    int colSupprimer = vue.modelUsers.getColumnCount() - 1;

                    if (col == colModifier) {
                        vue.setVisible(false);
                        new ModifierControleur("utilisateur", id, vue, idUser);
                    }

                    if (col == colSupprimer) {
                        supCtrl.supprimer("utilisateur", id);
                        chargerUsers();
                    }
                }
            });
        }
    }

    /* ================= RAFRAÎCHISSEMENT ================= */
    private void rafraichirTout() {
        chargerComptes();
        chargerOperations();
        chargerCategories();
        if (isAdmin) chargerUsers();
    }

    /* ================= CHARGEMENT ================= */

    public void chargerComptes() {
        try {
            vue.modelComptes.setRowCount(0);
            ResultSet rs = DashboardModele.getComptes(idUser);

            while (rs.next()) {
                vue.modelComptes.addRow(new Object[]{
                        rs.getInt("id_compte"),
                        rs.getString("nom_compte"),
                        rs.getDouble("solde"),
                        rs.getString("type"),
                        "Modifier",
                        "Supprimer"
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void chargerOperations() {
        try {
            vue.modelOperations.setRowCount(0);
            ResultSet rs = DashboardModele.getOperations(idUser);

            while (rs.next()) {
                vue.modelOperations.addRow(new Object[]{
                        rs.getInt("id_operations"),
                        rs.getString("libelle"),
                        rs.getDouble("montant"),
                        rs.getDate("date_depense"),
                        rs.getString("description"),
                        rs.getString("nom_compte"),
                        "Modifier",
                        "Supprimer"
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void chargerCategories() {
        try {
            vue.modelCategories.setRowCount(0);
            ResultSet rs = DashboardModele.getCategories();

            while (rs.next()) {
                vue.modelCategories.addRow(new Object[]{
                        rs.getInt("id_categorie"),
                        rs.getString("libelle"),
                        rs.getString("description"),
                        rs.getString("type"),
                        "Modifier",
                        "Supprimer"
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void chargerUsers() {
        try {
            vue.modelUsers.setRowCount(0);
            ResultSet rs = DashboardModele.getUsers();

            while (rs.next()) {
                vue.modelUsers.addRow(new Object[]{
                        rs.getInt("id_user"),
                        rs.getString("user"),
                        rs.getString("role"),
                        "Modifier",
                        "Supprimer"
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
