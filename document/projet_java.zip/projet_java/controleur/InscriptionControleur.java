package controleur;

import javax.swing.*;
import modele.UtilisateurModele;
import vue.InscriptionVue;

public class InscriptionControleur {

    private InscriptionVue vue;

    public InscriptionControleur() {

        vue = new InscriptionVue();

        vue.btnInscrire.addActionListener(e -> inscrire());

        vue.btnRetour.addActionListener(e -> {
            vue.dispose();          
            new LoginControleur(); 
        });
    }

    private void inscrire() {

        String user = vue.txtUser.getText();
        String mdp = new String(vue.txtMdp.getPassword());
        String nom = vue.txtNom.getText();
        String prenom = vue.txtPrenom.getText();

        if (user.isEmpty() || mdp.isEmpty() || nom.isEmpty() || prenom.isEmpty()) {
            JOptionPane.showMessageDialog(vue, "Tous les champs sont obligatoires");
            return; 
        }

        try {
            UtilisateurModele.inscription(user, mdp, nom, prenom);

            JOptionPane.showMessageDialog(vue, "Inscription réussie !");

            vue.dispose();
            new LoginControleur();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(vue, "Erreur lors de l'inscription");
            e.printStackTrace();
        }
    }
}
