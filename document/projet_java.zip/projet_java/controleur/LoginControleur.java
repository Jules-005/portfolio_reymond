package controleur;

import javax.swing.*;
import modele.UtilisateurModele;
import vue.LoginVue;

public class LoginControleur {

    private LoginVue vue;

    public LoginControleur() {

        vue = new LoginVue();

        vue.btnConnexion.addActionListener(e -> connecter());

        vue.btnInscription.addActionListener(e -> {
            vue.dispose();               
            new InscriptionControleur(); 
        });
    }

    private void connecter() {

        String user = vue.txtUser.getText();
        String mdp = new String(vue.txtMdp.getPassword());

        try {
            java.sql.ResultSet rs = UtilisateurModele.connexion(user, mdp);

            if (rs.next()) {

                int idUser = rs.getInt("id_user");
                boolean isAdmin =
                        rs.getString("role").equalsIgnoreCase("admin");

                vue.dispose();

                new DashboardControleur(idUser, isAdmin);

            } else {
                JOptionPane.showMessageDialog(vue, "Identifiants incorrects");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(vue, "Erreur de connexion");
            e.printStackTrace();
        }
    }
}
