package controleur;

import vue.DashboardVue;
import vue.FormulaireVue;
import modele.DashboardModele;

import javax.swing.*;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AjouterControleur {

    private int idUser;

    public AjouterControleur(String type, DashboardVue vue, int idUser) {
        this.idUser = idUser;

        // Masquer le dashboard
        vue.setVisible(false);

        FormulaireVue form = new FormulaireVue(vue, type);

        // Quand on ferme le formulaire → on réaffiche le dashboard
        form.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                vue.setVisible(true);
            }
        });

        // Charger comptes et catégories pour les opérations
        if (type.equals("operation")) {
            chargerComptes(form);
            chargerCategories(form);
        }

        form.btnAjouter.addActionListener(e -> ajouter(type, form));
        form.btnAnnuler.addActionListener(e -> form.dispose());

        form.setVisible(true);
    }

    /* ================= AJOUT ================= */
private void ajouter(String type, FormulaireVue form) {
    try {

        if (type.equals("compte")) ajouterCompte(form);
        else if (type.equals("operation")) ajouterOperation(form);
        else if (type.equals("categorie")) ajouterCategorie(form);
        else if (type.equals("utilisateur")) ajouterUtilisateur(form);

        form.dispose();

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(form, "Erreur : " + e.getMessage());
    }
}


    /* ================= COMPTE ================= */
    private void ajouterCompte(FormulaireVue form) throws Exception {
        String nom = form.tfNom.getText().trim();
        double solde = Double.parseDouble(form.tfSolde.getText().trim());
        String type = form.tfType.getText().trim();

        if (nom.isEmpty()) {
            JOptionPane.showMessageDialog(form, "Nom obligatoire");
            return;
        }

        DashboardModele.ajouterCompte(nom, solde, type, idUser);
    }

    /* ================= OPERATION ================= */
    private void chargerComptes(FormulaireVue form) {
        form.comptesIds = new ArrayList<>();
        try {
            ResultSet rs = DashboardModele.getComptes(idUser);
            while (rs.next()) {
                form.cbCompte.addItem(rs.getString("nom_compte"));
                form.comptesIds.add(rs.getInt("id_compte"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void chargerCategories(FormulaireVue form) {
        form.categoriesIds = new ArrayList<>();
        try {
            ResultSet rs = DashboardModele.getCategories();
            while (rs.next()) {
                form.cbCategorie.addItem(rs.getString("libelle"));
                form.categoriesIds.add(rs.getInt("id_categorie"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void ajouterOperation(FormulaireVue form) throws Exception {
        String libelle = form.tfLibelle.getText().trim();
        String date = form.tfDate.getText().trim();

        if (libelle.isEmpty() || date.isEmpty()) {
            JOptionPane.showMessageDialog(form, "Libellé et date obligatoires");
            return;
        }

        int indexCompte = form.cbCompte.getSelectedIndex();
        if (indexCompte < 0) {
            JOptionPane.showMessageDialog(form, "Sélectionnez un compte");
            return;
        }
        int idCompte = form.comptesIds.get(indexCompte);

        int indexCat = form.cbCategorie.getSelectedIndex();
        if (indexCat < 0) {
            JOptionPane.showMessageDialog(form, "Sélectionnez une catégorie");
            return;
        }
        int idCategorie = form.categoriesIds.get(indexCat);

        double montant;
        try {
            montant = Double.parseDouble(form.tfMontant.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(form, "Montant invalide");
            return;
        }

        DashboardModele.ajouterOperation(
            libelle,
            montant,
            date,
            form.tfDesc.getText().trim(),
            idCompte,
            idCategorie
        );
    }

    /* ================= CATEGORIE ================= */
    private void ajouterCategorie(FormulaireVue form) throws Exception {
        String lib = form.tfCatLibelle.getText().trim();

        if (lib.isEmpty()) {
            JOptionPane.showMessageDialog(form, "Libellé obligatoire");
            return;
        }

        int typeId = form.cbTypeOp.getSelectedIndex() + 1;
        DashboardModele.ajouterCategorie(lib, form.tfCatDesc.getText().trim(), typeId);
    }


private void ajouterUtilisateur(FormulaireVue form) throws Exception {

    String login = form.tfUserLogin.getText().trim();
    String nom = form.tfUserNom.getText().trim();
    String prenom = form.tfUserPrenom.getText().trim();
    String mdp = form.tfUserMdp.getText().trim();
    boolean admin = form.cbAdmin.isSelected();

    if(login.isEmpty() || nom.isEmpty() || prenom.isEmpty() || mdp.isEmpty()){
        JOptionPane.showMessageDialog(form,"Tous les champs obligatoires");
        return;
    }

    DashboardModele.ajouterUtilisateur(login, mdp, nom, prenom, admin);
}

}