package controleur;

import vue.DashboardVue;
import modele.DashboardModele;

import javax.swing.*;
import java.sql.SQLException;

public class SupprimerControleur {

    private DashboardVue vue;

    public SupprimerControleur(DashboardVue vue) {
        this.vue = vue;
    }

    public void supprimer(String type, int id) {

        int confirm = JOptionPane.showConfirmDialog(
                vue,
                "Supprimer ce " + type + " ?",
                "Confirmation",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                switch (type) {

                    case "compte":
                        DashboardModele.supprimerCompte(id);
                        break;

                    case "operation":
                        DashboardModele.supprimerOperation(id);
                        break;

                    case "categorie":
                        DashboardModele.supprimerCategorie(id);
                        break;

                    case "utilisateur":
                        DashboardModele.supprimerUtilisateur(id);
                        break;
                }

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(
                        vue,
                        "Erreur lors de la suppression : " + e.getMessage()
                );
            }
        }
    }
}
