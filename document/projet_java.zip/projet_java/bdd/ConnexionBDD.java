package bdd;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnexionBDD {

    public static Connection getConnexion() {
        String url = "jdbc:mysql://localhost:3306/operations_banque";
        String user = "root";
        String password = "";

        Connection cn = null;
        try {
            cn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cn;
    }
}
